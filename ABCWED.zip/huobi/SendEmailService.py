# !/usr/bin/python
# -*- coding: UTF-8 -*-

import smtplib
from email.mime.text import MIMEText
from email.header import Header
from HuobiOrdersRecord import *
from HuobiServicesHadax import *
from HuobiServices import *
import datetime
import time
import traceback

class SendEmailService:
    # 第三方 SMTP 服务
    mail_host = "smtp.163.com"  # 设置服务器
    mail_user = "13180368090@163.com"  # 用户名
    mail_pass = "chuanfa921209"  # 口令
    message = MIMEText('Python 邮件发送测试...', 'plain', 'utf-8')
    message['From'] = Header("菜鸟教程", 'utf-8')
    message['To'] = Header("测试", 'utf-8')
    subject = 'Python SMTP 邮件测试'
    message['Subject'] = Header(subject, 'utf-8')
    procoinset = []
    hadaxcoinset = []
    procoin = []
    hadaxcoin = []
    def __init__(self, host, user, passwd):
        self.mail_host = host
        self.mail_user = user
        self.mail_pass = passwd
        self.receivers = ['13180368090@163.com']  # 接收邮件，可设置为你的QQ邮箱或者其他邮箱
        self.sender = '13180368090@163.com'
        self.procoinset = []
        self.hadaxcoinset = []
        self.procoin = []
        self.hadaxcoin = []

    def getYesterday(self):
        today = datetime.date.today()
        oneday = datetime.timedelta(days=1)
        yesterday = today - oneday
        return yesterday


    def find_the_coin_in_balance(self, balance, coin):
        for b in balance:
            if coin == b[0]:
                return b

    def obtaining_the_amount_of_huobi_assets(self):
        balance = get_balance(3654291)['data']['list']
        for b in range(0, len(balance)):
            if float(balance[b]['balance']) != 0.0:
                item = self.find_the_coin_in_balance(self.procoinset, balance[b]['currency'])
                if None == item:
                    item = (balance[b]['currency'], {'trade': [0.0, 0.0]}, {'frozen': [0.0, 0.0]}, 0.0,0.0)
                    self.procoinset.append(item)
                if balance[b]['type'] == 'frozen':
                    item[2]['frozen'][0] = round(float(balance[b]['balance']),6)
                if balance[b]['type'] == 'trade':
                    item[1]['trade'][0] = round(float(balance[b]['balance']), 6)
        balance = get_balance_h(3654291)['data']['list']
        for b in range(0, len(balance)):
            if float(balance[b]['balance']) != 0.0:
                if 'eth' != balance[b]['currency'] and 'usdt' != balance[b]['currency'] and 'btc' != balance[b]['currency']:
                    item = self.find_the_coin_in_balance(self.hadaxcoinset, balance[b]['currency'])
                    if None == item:
                        item = (balance[b]['currency'], {'trade': [0.0, 0.0]}, {'frozen': [0.0, 0.0]}, 0.0,0.0)
                        self.hadaxcoinset.append(item)
                    if balance[b]['type'] == 'frozen':
                        item[2]['frozen'][0] = round(float(balance[b]['balance']),6)
                    if balance[b]['type'] == 'trade':
                        item[1]['trade'][0] = round(float(balance[b]['balance']), 6)

    def obtaining_the_amount_of_pro_assets(self):
        for coin in self.procoinset:
            time.sleep(1)
            if coin[0] != 'usdt':

                xrp = get_ticker(coin[0] + 'usdt')
                if xrp == None:
                    xrp = get_ticker(coin[0] + 'eth')
                print(xrp,coin[0])
                price = 0.0
                if xrp['tick']['bid'] != None:
                    price = round(float(xrp['tick']['bid'][0]), 6)
                trade = round(float(coin[1]['trade'][0]), 6)
                frozen = round(float(coin[2]['frozen'][0]), 6)
                v1 = round(float(price) * trade, 6)
                v2 = round(float(price) * frozen, 6)
                # coin[1]['trade'][1] = v1
                # coin[2]['frozen'][1] = v2
                # coin[3] = price
                # coin[4] = v1+v2
            else:#deal with usdt
                price = 1.0
                trade = round(float(coin[1]['trade'][0]), 6)
                frozen = round(float(coin[2]['frozen'][0]), 6)
                v1 = round(float(price) * trade, 6)
                v2 = round(float(price) * frozen, 6)
                # coin[1]['trade'][1] = v1
                # coin[2]['frozen'][1] = v2
                # coin[3] = price
                # coin[4] = v1+v2
            self.procoin.append((coin[0],{'trade':[trade,v1]},{'frozen':[frozen,v2]},price,v1+v2))

    def obtaining_the_amount_of_hadax_assets(self):
        for coin in self.hadaxcoinset:
            time.sleep(1)
            if coin[0] != 'eth':
                xrp = get_ticker_h(coin[0] + 'eth')
                if xrp == None:
                    xrp = get_ticker(coin[0] + 'usdt')
                price = round(float(xrp['tick']['bid'][0]), 6)
                trade = round(float(coin[1]['trade'][0]), 6)
                frozen = round(float(coin[2]['frozen'][0]), 6)
                v1 = round(float(price) * trade, 6)
                v2 = round(float(price) * frozen, 6)
                # coin[1]['trade'][1] = v1
                # coin[2]['frozen'][1] = v2
                # coin[3] = price
                # coin[4] = v1+v2
                self.hadaxcoin.append((coin[0], {'trade': [trade, v1]}, {'frozen': [frozen, v2]}, price, v1 + v2))
    def send_Email(self, message):
        try:
            smtpObj = smtplib.SMTP()
            smtpObj.connect(self.mail_host, 25)  # 25 为 SMTP 端口号
            smtpObj.login(self.mail_user, self.mail_pass)
            smtpObj.sendmail(self.sender, self.receivers, message.as_string())
            print("邮件发送成功")
        except smtplib.SMTPException:
            print("Error: 无法发送邮件")

    def collect_infomations_and_send_email(self):
        dbmanager = HuobiOrdersRecord('db/huobi.db')
        msg = '尊敬的张先生,\n	\t截止到' + time.strftime("%Y-%m-%d %H:%M:", time.localtime()) + '08 您账户中的资产以及自动交易详细情况如下：\n'
        msg += '\tpro账户：\n'
        total = 0
        self.obtaining_the_amount_of_huobi_assets()
        self.obtaining_the_amount_of_pro_assets()
        for c in self.procoin:
            v1 = c[1]['trade'][0]
            v2 = c[2]['frozen'][0]
            msg += '\t\t' + str(c[0]) + '\t可用:' + str(v1) + '\t冻结：' + str(v2) + '\t总额：' + str(round((v1 + v2),6)) + '\t总价值：' + str(
                round(c[4],6)) + ' usdt\n'
            total += c[4]
        msg += '\t\t\t总计：' + str(round(total,6)) + ' usdt\n'
        total = 0
        msg += '\thadax账户：\n'
        self.obtaining_the_amount_of_hadax_assets()
        for c in self.hadaxcoin:
            v1 = c[1]['trade'][0]
            v2 = c[2]['frozen'][0]
            msg += '\t\t' + str(c[0]) + '\t可用:' + str(v1) + '\t冻结：' + str(v2) + '\t总额：' + str(round((v1 + v2),6)) + '\t总价值：' + str(
                round(c[4],6)) + ' eth\n'
            total += c[4]
        msg += '\t\t\t总计：' + str(round(total,6)) + ' eth\n'
        msg += '\t自动交易账户统计：\n'
        totalearn = 0.0
        all = dbmanager.fetchall_huobi_table()
        for table in all:
            dbmanager.setTable(table[0])
            # where
            # finished_at > ? \
            #         and finished_at < ? and state =? and type =?;'''
            date = str(self.getYesterday())
            # date1 = '2018-05-03'
            # date2 = '2018-05-03'
            data = [date + ' 00:00:00', date + ' 24:00:00', 'filled', 'buy-limit']
            buy = dbmanager.get_huobi_table_cnt(data)
            data[2] = 'canceled'
            buycancel = dbmanager.get_huobi_table_cnt(data)
            data[3] = 'sell-limit'
            sellcancel = dbmanager.get_huobi_table_cnt(data)
            data[2] = 'filled'
            sell = dbmanager.get_huobi_table_cnt(data)
            symbolstart = str(table).find('_')
            symbolend   = str(table).rfind('_')
            symbol = str(table)[symbolstart+1:symbolend]
            xrp = get_ticker_h(symbol)
            if xrp == None:
                xrp = get_ticker(symbol)
            price = 0.0
            if xrp['tick']['bid'] != None:
                price = round(float(xrp['tick']['bid'][0]), 6)
            data = [date + ' 00:00:00', date + ' 24:00:00', 'filled', 'sell-limit']
            sellamount = dbmanager.get_huobi_table_sell_filled_amount(data)
            ethprice = 1.0
            if sellamount[0] != None:
                floatvalue=str(sellamount[0])
                if symbol.find('eth')>0 :
                    xrp = get_ticker('ethusdt')
                    if xrp['tick']['bid'] != None:
                        ethprice = round(float(xrp['tick']['bid'][0]), 6)
                earned = float(floatvalue) * float(price*ethprice) * 0.01 * 6.4
            else:
                earned = 0.0
            totalearn += earned
            msg += '\t\t' + table[0] + '： 买入' + str(buy) + ' 笔; 卖出 ' + str(sell) + ' 笔; 取消买入： ' + str(
                buycancel) + ' 笔; 取消卖出： ' + str(sellcancel) + ' 卖出总量： '+str(sellamount) +' 当前价格： '+str(price)+' 收益约为： '+ str(earned)+'\n'
        msg += '\t\t 昨日总收益 RMB ： ' + str(totalearn) +'\n'
        message = MIMEText(msg, 'plain', 'utf-8')
        message['From'] = Header("smarter", 'utf-8')
        message['To'] = Header("cfzhang", 'utf-8')
        subject = '来自国外火币智能交易系统'
        message['Subject'] = Header(subject, 'utf-8')
        self.send_Email(message)
if __name__ == '__main__':
    semail = SendEmailService("smtp.163.com", "13180368090@163.com", "chuanfa921209")
    while True:
        # 判断是否达到设定时间，例如0:00
        while True:

            now = datetime.datetime.now()
            time.sleep(5)
            # 到达设定时间，结束内循环
            if now.hour==8 and now.minute==8:
                break
            # 不到时间就等20秒之后再次检测
    # 做正事，一天做一次
        try:
            semail.collect_infomations_and_send_email()
            semail.procoinset.clear()
            semail.procoin.clear()
            semail.hadaxcoinset.clear()
            semail.hadaxcoin.clear()
        except Exception:
            print('traceback.print_exc():', traceback.print_exc())
        time.sleep(100)
