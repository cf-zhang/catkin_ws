from SqliteUtils import *



#交易ID 时间 交易对 方向 价格 委托量 成交数量 成交均价 订单状态 手续费
class HuobiOrdersRecord:
    db = ''
    table = ''
    def __init__(self, db, table=''):
        self.db = db
        self.table = table
    def setTable(self,table):
        self.table = table

    def drop_huobi_table(self):
        '''删除数据库表测试'''
        print('删除数据库表测试...')
        conn = get_conn(self.db)
        drop_table(conn, self.table)

    def create_huobi_table(self):
        '''创建数据库表测试'''
        print('创建数据库表测试...')
        create_table_sql = '''CREATE TABLE IF NOT EXISTS '''+self.table+''' (
                                `id` varchar(40) NOT NULL,
                                `symbols` varchar(40) NOT NULL,
                                `amount` varchar(40) NOT NULL,
                                `price` varchar(40) NOT NULL,
                                `created_at` TEXT NOT NULL,
                                `canceled_at` TEXT NOT NULL,
                                `finished_at` TEXT NOT NULL,
                                `type` varchar(40) NOT NULL,
                                `field_amount` varchar(40) NOT NULL,
                                `field_cash_amount` varchar(40) NOT NULL,
                                `field_fees` varchar(40) NOT NULL,
                                `state` varchar(40) NOT NULL,
                                `outofdate` varchar(40),
                                PRIMARY KEY (`id`)
                            )'''
        conn = get_conn(self.db)
        create_table(conn, create_table_sql)

    def update_huobi_record(self, data):
        '''更新数据...'''
        print('更新数据...')
        update_sql = 'UPDATE ' + self.table + ' SET state = ?,finished_at = ?,field_amount = ?, field_cash_amount = ?,field_fees = ? WHERE id = ? '
        # data = [(field_amount, id)]
        conn = get_conn(self.db)
        update(conn, update_sql, data)

    def set_huobi_order_outofdate(self,id):
        '''更新数据...'''
        print('更新数据设置outofdate...')
        update_sql = 'UPDATE ' + self.table + ' SET outofdate = ? WHERE id = ? '
        data = [('true', id)]
        conn = get_conn(self.db)
        update(conn, update_sql, data)

    def save_huobi_records(self,data):
        '''保存数据测试...'''
        print('保存数据测试...')
        save_sql = '''INSERT INTO '''+self.table+''' values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'''
        # data = [('123456789', '2018-4-2-3 10:29:00', 'btcusdt', 'buy', '2.06520','500', '300', '2.015',
        #      'partial-filled', '0.2396')
        #     ]
        conn = get_conn(self.db)
        save(conn, save_sql, data)

    def get_huobi_table_cnt(self,data):
        '''查询所有数据...'''
        print('查询所有数据...')

        fetchall_sql = '''select count(*) from '''+self.table+''' where finished_at > ? \
                        and finished_at < ? and state=? and type=?;'''
        conn = get_conn(self.db)
        result = fetchall(conn, fetchall_sql, data)
        return result[0];

    def get_huobi_table_sell_filled_amount(self,data):
        '''查询所有数据...'''
        print('查询所有数据...')

        fetchall_sql = '''select sum(CAST(amount AS float)) from ''' + self.table + ''' where finished_at > ? \
                                and finished_at < ? and state=? and type=?;'''
        conn = get_conn(self.db)
        result = fetchall(conn, fetchall_sql, data)
        return result[0];

    def fetchall_huobi_records(self):
        '''查询所有数据...'''
        print('查询所有数据...')
        fetchall_sql = '''SELECT * FROM ''' + self.table
        conn = get_conn(self.db)
        return fetchall(conn, fetchall_sql)
    #获取所有的数据库表
    def fetchall_huobi_table(self):
        '''查询所有数据...'''
        print('查询所有数据...')
        fetchall_sql = '''select name from sqlite_master where type = 'table' order by name'''
        conn = get_conn(self.db)
        return fetchall(conn, fetchall_sql)

    # 查询所有买入，未成交，非撤销的挂单
    def fetchall_huobi_nodeal_buy_records_id(self):
        '''查询所有未成交的买入数据...'''
        print('查询所有未成交的买入数据...')
        fetchall_sql = '''SELECT id FROM '''+self.table+''' WHERE type = ? and state != ? and outofdate=?'''
        data=['buy-limit','canceled','false']
        conn = get_conn(self.db)
        result = fetchall(conn, fetchall_sql, data)
        ids = []
        if result is not None:
            for r in result:
                ids.append([str(r[0]),'0.0','0.0',False])
        return ids

    # 查询所有卖出，未成交或者未卖出的挂单
    def fetchall_huobi_nodeal_sell_records_id(self):
        '''查询所有未成交的买入数据...'''
        print('查询所有未成交的买入数据...')
        fetchall_sql = '''SELECT id FROM '''+self.table+''' WHERE type = ? and state != ? and outofdate=?'''
        data=['sell-limit','canceled','false']
        conn = get_conn(self.db)
        result = fetchall(conn, fetchall_sql, data)
        ids = []
        if result is not None:
            for r in result:
                ids.append([str(r[0]),'0.0','0.0',False])
        return ids

    def fetchall_huobi_sell_records(self):
        '''查询所有数据...'''
        print('查询所有数据...')
        fetchall_sql = '''SELECT * FROM '''+self.table
        conn = get_conn(self.db)
        return fetchall(conn, fetchall_sql)

    def fetchone_huobi_record(self,data):
        '''查询一条数据...'''
        print('查询一条数据...')
        fetchone_sql = 'SELECT * FROM '+self.table+' WHERE order_id = ? '
        # data = 1
        conn = get_conn(self.db)
        fetchone(conn, fetchone_sql, data)



    def delete_huobi_record(self,id):
        '''删除数据...'''
        print('删除数据...')
        delete_sql = 'DELETE FROM '+self.table+' WHERE order_id ='+id
        conn = get_conn(self.db)
        delete(conn, delete_sql)


###############################################################
####            测试操作     END
###############################################################

    # def huobi_order_record_init():
    #     '''初始化方法'''
        # 数据库文件绝句路径
        # global DB_FILE_PATH
        # DB_FILE_PATH = '/home/cfzhang/PycharmProjects/huobi/db/huobi.db'
        # 数据库表名称
        # global TABLE_NAME
        # TABLE_NAME = 'huobi_order_record'
        # 是否打印sql
        # global SHOW_SQL
        # SHOW_SQL = True
        # print('show_sql : {}'.format(SHOW_SQL))
        # 如果存在数据库表，则删除表
        # drop_huobi_table()
        # 创建数据库表student
        # create_huobi_table()
        # 向数据库表中插入数据
        # save_huobi_records()

#
# def main():
#     huobi_order_record_init()
#     fetchall_huobi_records()
#     print('#' * 50)
#     fetchone_huobi_record('123456789')
#     print('#' * 50)
#     update_huobi_record('123456789','123')
#     fetchall_huobi_records()
#     print('#' * 50)
#     delete_huobi_record('123456789')
#     fetchall_huobi_records()
#
#
# if __name__ == '__main__':
#     main()