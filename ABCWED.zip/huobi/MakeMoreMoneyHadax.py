from HuobiServicesHadax import *
from HuobiOrdersRecord import *
import time
import threading
import traceback

class MakeMoreMoneyHadax(threading.Thread):
    reduceratiotobuy = 0.0  # 下跌百分比就进行买入
    increaseratiotosell = 0.0 #上涨百分比就卖出
    muchlessthantobuy = 0.0 #价格远低于已经买入订单
    muchmorethantobuy = 0.0 #价格远高于已经买入订单
    cancelmuchlessbuy = 0.04 #订单价格远低于当前买一价格百分比，进行取消挂的买单
    cancelmuchmoresell = 0.04 #订单价格远低于当前卖一价格百分比，进行取消挂的卖单
    freq = 1 #循环频率 次/S，每次都会检查订单状态
    freq_trade = 2 #买卖逻辑的进入控制，间隔为 freq×freq_trade
    freq_update_order_state = 60 #订单控制，当达到这个时间以后进行订单撤销,间隔为freq×freq_update_order_state
    freq_cancel_order = 60 #订单取消逻辑频率控制，当时间为freq_update_order_state×freq_cancel_order×freq的大小
    # 已经买入了的价格池，以订单 id：价格：数量 元祖进行统计
    record = []  # id,price,amount,isfinished
    sellrecord = []  # 卖出的记录链表
    newer = 0.00001395  # 最新一次的已经买入了的价格，作为下次买入的判断
    continuousdecline = 0  # 连续下跌的次数，用于补仓时计算买入比例
    curbalance = 0.0  # 当前账户可用余额，与continusdecline联合计算应该买入的金额
    bid = 0.0  # 买1价
    ask = 0.0  # 卖1价
    coin = '' #交易的币种
    money = '' #货币种类
    partoftotalbalance = 1 #当前账户余额的1/1,用于该币种买入
    ratio_nc = [0.125,0.5,0.5,0.5,0.05]#买入价格梯度列表

    def __init__(self, strategy):
        threading.Thread.__init__(self)
        # 从配置中获取策略信息
        self.reduceratiotobuy = strategy['reduceratiotobuy']
        self.increaseratiotosell = strategy['increaseratiotosell']
        self.muchlessthantobuy = strategy['muchlessthantobuy']
        self.muchmorethantobuy = strategy['muchmorethantobuy']
        self.cancelmuchlessbuy = strategy['cancelmuchlessbuy']
        self.cancelmuchmoresell = strategy['cancelmuchmoresell']
        self.newer = strategy['newer']
        self.coin = strategy['coin']
        self.money = strategy['money']
        self.partoftotalbalance = strategy['partoftotalbalance']
        self.ratio_nc = strategy['ratio_nc']
        self.freq = strategy['freq']
        self.freq_trade = strategy['freq_trade']
        self.freq_update_order_state = strategy['freq_update_order_state']
        self.freq_cancel_order = strategy['freq_cancel_order']
        # 已经买入了的价格池，以订单 id：价格：数量 元祖进行统计
        self.record = []  # id,price,amount,isfinished
        self.sellrecord = []  # 卖出的记录链表
        self.continuousdecline = 0  # 连续下跌的次数，用于补仓时计算买入比例
        self.curbalance = 0.0  # 当前账户可用余额，与continusdecline联合计算应该买入的金额
        # 设置一些上下限 阀值等数据量
        self.bid = 0.0  # 买1价
        self.ask = 0.0  # 卖1价
        self.symbol = self.coin + self.money

        # 读取数据库信息，建立数据库表
        db = strategy['database']
        table = 'huobi_'+self.symbol+'_records'
        self.dbobj = HuobiOrdersRecord(db, table)
        self.dbobj.create_huobi_table()


    def print_strategy(self):
        print(self.reduceratiotobuy)
        print(self.increaseratiotosell)
        print(self.muchlessthantobuy)
        print(self.muchmorethantobuy)
        print(self.freq)
        print(self.newer)
        print(self.continuousdecline)
        print(self.curbalance)
        print(self.coin)
        print(self.money)
        print(self.symbol)
        print(self.partoftotalbalance)
        print(self.ratio_nc)
        print(self.cancelmuchlessbuy)
        print(self.cancelmuchmoresell)
        print(self.freq_update_order_state)
        print(self.freq_cancel_order)



    def buy_some_by_ratio(self, ratio):
        self.newer = self.bid;
        # 按照1/8的余额进行买入,计算数量，和确定单价
        print("按照" + str(ratio) + "的余额进行买入,计算数量，和确定单价 in " + self.coin)
        wantbuyamount = round(self.curbalance * self.partoftotalbalance * ratio / self.bid, 2)
        wantbuyprice = round(self.bid, 8)
        id = send_order(str(wantbuyamount), 'api', self.symbol, 'buy-limit', str(wantbuyprice))['data']
        # id = send_order(str(wantbuyamount), 'api', self.symbol, 'buy-limit', str(wantbuyprice))
        if id != None:
            self.record.append([str(id), str(wantbuyprice), str(0.0), False])  # 将订单id存放起来，后续会进行查询更新价格和数量
            #数据库记录
            data = [(str(id),self.symbol,str(wantbuyamount),str(wantbuyprice),time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()),'','',
                     'buy-limit','0.0','0.0','0.0','submitting', 'false')]
            self.dbobj.save_huobi_records(data)
        return id


    def check_for_update_buy_orders(self):
        # 更新record中的价格和数量，每分钟都要进行执行
        for r in self.record:
            print(r)
            if r[0] != '':
                time.sleep(0.1)
                order = order_info(str(r[0]))
                if None != order:
                    print(order)
                    if order['data']['state'] == 'filled' and r[3] != True:
                        r[3] = True
                        r[1] = str(round(float(order['data']['price']), 10))
                        r[2] = str(round(float(order['data']['field-amount']), 2))
                        field_cash_amount = order['data']['field-cash-amount']
                        field_fees = order['data']['field-fees']
                        #订单完成更新数据库
                        data = [('filled',time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), r[2], str(field_cash_amount), str(field_fees), r[0])]
                        self.dbobj.update_huobi_record(data)
                #
    def check_for_update_sell_orders(self):
        # 更新record中的价格和数量，每分钟都要进行执行
        for r in self.sellrecord:
            print(r)
            if r[0] != '':
                time.sleep(0.1)
                order = order_info(str(r[0]))
                if None != order:
                    print(order)
                    if order['data']['state'] == 'filled':
                        r[3] = True
                        r[1] = str(round(float(order['data']['price']), 10))
                        r[2] = str(round(float(order['data']['field-amount']), 2))
                        field_cash_amount = order['data']['field-cash-amount']
                        field_fees = str(float(order['data']['field-fees']) * float(r[2]))
                        #订单完成更新数据库
                        data = [('filled',time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), str(r[2]), str(field_cash_amount), str(field_fees), r[0])]
                        self.dbobj.update_huobi_record(data)
                        self.dbobj.set_huobi_order_outofdate(r[0])
                        self.sellrecord.remove(r)


    def check_for_cancel_zombie_buy_orders(self):
        # 如果订单的挂单价格远低于当前买1的价格，比如为4%（可配置）则取消
        for r in self.record:
            if r[0] != '':
                time.sleep(0.1)
                order = order_info(str(r[0]))
                if order['data']['state'] != 'filled':
                    r[3] = False
                    r[1] = str(round(float(order['data']['price']), 10))
                    r[2] = str(round(float(order['data']['field-amount']), 2))
                    field_cash_amount = order['data']['field-cash-amount']
                    field_fees = order['data']['field-fees']
                    if (float(r[1]) - self.bid) / self.bid < (self.cancelmuchlessbuy * -1):
                        #如果是部分成交，但是也走到了这个逻辑，那么部分成交的币暂时先不做处理，作为其他买卖的手续币
                        #取消订单
                        status = cancel_order(r[0])
                        #订单成功取消后更新数据库,设置过期标志位
                        if status['status'] == 'ok':
                            data = [('canceled',time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), r[2], str(field_cash_amount), str(field_fees), r[0])]
                            self.dbobj.update_huobi_record(data)
                            self.dbobj.set_huobi_order_outofdate(r[0])
                            self.record.remove(r)
                            print('取消了一个买入订单:'+r[0])

    def check_for_cancel_zombie_sell_orders(self):
        # 如果订单的挂单价格远低于当前买1的价格，比如为4%（可配置）则取消
        for r in self.sellrecord:
            time.sleep(0.1)
            if r[0] != '':
                order = order_info(str(r[0]))
                if order['data']['state'] != 'filled':
                    r[3] = False
                    r[1] = str(round(float(order['data']['price']), 10))
                    r[2] = str(round(float(order['data']['field-amount']), 2))
                    field_cash_amount = order['data']['field-cash-amount']
                    field_fees = order['data']['field-fees']
                    if (float(r[1]) - self.bid) / self.bid < (self.cancelmuchmoresell):
                        # 如果是部分成交，但是也走到了这个逻辑，那么部分成交的币暂时先不做处理，作为其他买卖的手续币
                        # 取消订单
                        status = cancel_order(r[0])
                        # 订单成功取消后更新数据库，设置过期标志位
                        if status['status'] == 'ok':
                            data = [('canceled', time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), r[2],
                                     str(field_cash_amount), str(field_fees), r[0])]
                            self.dbobj.update_huobi_record(data)
                            self.dbobj.set_huobi_order_outofdate(r[0])
                            self.sellrecord.remove(r)
                            print('取消了一个卖出订单:' + r[0])

    def check_for_cancel_zombie_orders(self):
        self.check_for_cancel_zombie_buy_orders()
        self.check_for_cancel_zombie_sell_orders()


    def refresh_cur_balance_and_price(self):
        print("获取当前余额：")
        xrp = get_ticker(self.symbol)
        balance = get_balance(3654291)['data']['list']
        for it in balance:
            if it['currency'] == self.money and it['type'] == "trade":
                self.curbalance = float(it['balance'])  # 获取余额
        print(self.curbalance)
        # print("获取价格")
        self.bid = round(float(xrp['tick']['bid'][0]), 10)
        self.ask = round(float(xrp['tick']['ask'][0]), 10)
        print("last value " + str(self.newer) + " current value " + str(self.bid))


    def check_for_sell_coins(self):
        for r in self.record:
            if float(r[1]) != 0.0 \
                    and (self.ask - round(float(r[1]), 10)) / float(r[1]) > self.increaseratiotosell \
                    and float(r[2]) > 0:  # 只要升值了就卖出去
                self.continuousdecline = 0
                # 限价卖
                id = send_order(r[2], 'api', self.symbol, 'sell-limit', str(self.ask))['data']
                if id != None:
                    if r[3] == True:
                        self.record.remove(r)
                        self.dbobj.set_huobi_order_outofdate(r[0])
                    else:
                        r[2] = str(0.0)
                    self.sellrecord.append([str(id), '0.0', '0.0', False])

                    # 数据库记录
                    data = [(str(id), self.symbol, r[2], str(self.ask),
                             time.strftime("%Y-%m-%d %H:%M:%S", time.localtime()), '', '',
                             'sell-limit', '0.0', '0.0', '0.0', 'submitting', 'false')]
                    self.dbobj.save_huobi_records(data)
                    self.newer = self.ask
                    print("卖了一单,price: " + str(self.newer))


    def deal_with_muchlessthan(self):
        muchlessthan = False
        for r in self.record:
            if float(r[1]) != 0.0 and (round(float(r[1]), 8) - self.bid) / float(r[1]) > self.muchlessthantobuy:
                muchlessthan = True
            else:
                muchlessthan = False
                break
        if True == muchlessthan:  # 当前价格远小于帐号中已经存在的订单，那么按照1/12进行买入一单
            # 按照1/12的余额进行买入,计算数量，和确定单价
            # print("价格远低于当前")
            self.buy_some_by_ratio(self.ratio_nc[4])


    def deal_with_muchmorethan(self):
        muchmorethan = False
        for r in self.record:
            if float(r[1]) != 0.0 and (round(float(r[1]), 8) - self.bid) / float(r[1]) < (-1 * self.muchmorethantobuy):
                muchmorethan = True
            else:
                muchmorethan = False
                break
        if True == muchmorethan:  # 当前价格远大于帐号中已经存在的订单，那么按照1/24进行买入一单
            # 按照1/12的余额进行买入,计算数量，和确定单价
            # print("价格远超当前")
            self.buy_some_by_ratio(self.ratio_nc[4])


    def make_deals(self):
        loopCnt = 1  # 计时次数，以1分钟作为控制步长
        while True:
            try:
                self.check_for_update_buy_orders()
                # 买入或者卖出逻辑
                if loopCnt % self.freq_trade == 0:  # 每2分钟进行一次买入和卖出判断
                    # 获取当前余额 获取价格
                    self.refresh_cur_balance_and_price()
                    # 根据价格判断买入情况
                    # print("根据价格判断买入或者卖出情况")
                    if self.bid < self.newer and self.curbalance > self.bid:  # 本次查询到的价格低于已经买入过的价格
                        # print("本次查询到的价格低于已经买入过的价")
                        if (self.newer - self.bid) / self.newer > self.reduceratiotobuy:
                            if self.continuousdecline < 3:
                                self.buy_some_by_ratio(self.ratio_nc[self.continuousdecline])
                            else:
                                self.buy_some_by_ratio(self.ratio_nc[3])
                            self.continuousdecline += 1
                    else:
                        # print("在卖出逻辑中进行判断卖出标准")
                        if len(self.record) == 0:
                            # 按照的余额进行买入,计算数量，和确定单价
                            # print("当前订单记录为空")
                            self.buy_some_by_ratio(self.ratio_nc[4])
                        else:
                            self.check_for_sell_coins()
                            self.deal_with_muchlessthan()
                            self.deal_with_muchmorethan()

                if loopCnt % self.freq_update_order_state == 0:
                    # 挂单队列处理以及统计
                    # print("挂单队列处理以及统计")
                    self.check_for_update_sell_orders()
                if loopCnt % self.freq_cancel_order == 0:
                    self.check_for_cancel_zombie_orders()
            except Exception:
                print('traceback.print_exc():', traceback.print_exc())
            # except:
            #     print("发生异常")
            time.sleep(self.freq)  # 休眠1分钟
            loopCnt += 1

    def records_init(self):
        self.record = self.dbobj.fetchall_huobi_nodeal_buy_records_id()
        self.sellrecord = self.dbobj.fetchall_huobi_nodeal_sell_records_id()

    def run(self):
        self.records_init()
        # self.check_for_update_sell_orders()
        self.make_deals()
