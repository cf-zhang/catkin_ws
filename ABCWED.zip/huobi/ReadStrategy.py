import yaml,os
import time

class ReadStrategy:
    def __init__(self, strategyfile):
        filename = os.path.join(os.path.dirname(__file__), strategyfile).replace("\\", "/")
        fp = open(filename)
        self.strategies = yaml.load(fp)
    def get_strategies(self):
        return self.strategies






if __name__ == '__main__':
    #获取文件全路径
    rs = ReadStrategy('yaml/prostrategy.yaml')
    print(os.path.join(os.path.dirname(__file__)))
    strategies = rs.get_strategies()
    for s in strategies:
        print(s)
    # 格式化成2016-03-20 11:45:39形式
