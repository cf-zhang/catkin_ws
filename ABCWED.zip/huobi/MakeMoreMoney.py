from MakeMoreMoneyPro import *
from MakeMoreMoneyHadax import *
from ReadStrategy import *


if __name__ == '__main__':

    pro_rs = ReadStrategy('yaml/prostrategy.yaml').get_strategies()
    hadax_rs = ReadStrategy('yaml/hadaxstrategy.yaml').get_strategies()
    protasks = []

    for rs in pro_rs:
        task = MakeMoreMoneyPro(rs)
        # task.print_strategy()
        protasks.append(task)
    for rs in hadax_rs:
        task = MakeMoreMoneyHadax(rs)
        # task.print_strategy()
        protasks.append(task)

    for task in protasks:
        task.start()

    for task in protasks:
        task.join()
